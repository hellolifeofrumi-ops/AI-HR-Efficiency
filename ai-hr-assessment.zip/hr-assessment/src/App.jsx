import { useState } from "react";

const questions = [
  {
    id: 1,
    domain: "Talent Acquisition",
    icon: "🎯",
    question: "Your talent team receives 800+ applications for a single role. How do you currently use AI in your screening process?",
    type: "mcq",
    options: [
      { label: "A", text: "We manually review all CVs — no AI tools in use", score: 0 },
      { label: "B", text: "We use basic keyword filters in our ATS to shortlist candidates", score: 1 },
      { label: "C", text: "We use AI-powered ATS (e.g. Greenhouse, Workday AI) with weighted criteria scoring to rank candidates and auto-schedule interviews", score: 2 },
      { label: "D", text: "We run multi-model AI screening with structured bias audits, video interview analysis (e.g. HireVue), and predictive performance scoring benchmarked against top performers", score: 3 },
    ],
  },
  {
    id: 2,
    domain: "HR Analytics",
    icon: "📊",
    question: "Your CHRO asks for a predictive attrition report for the next two quarters. What is your team's capability?",
    type: "mcq",
    options: [
      { label: "A", text: "We track headcount and exit surveys in spreadsheets — no predictive capability", score: 0 },
      { label: "B", text: "We use HRIS reports and basic dashboards (e.g. Power BI) with historical attrition trends", score: 1 },
      { label: "C", text: "We use people analytics tools (e.g. Visier, One Model) with ML-driven attrition models factoring in engagement scores, tenure, and pay data", score: 2 },
      { label: "D", text: "We run real-time predictive models with 90%+ accuracy (like IBM Watson Talent Insights), feeding automated retention nudges to managers with prescriptive action plans", score: 3 },
    ],
  },
  {
    id: 3,
    domain: "Employee Experience",
    icon: "💬",
    question: "An employee feels disengaged and has no clarity on their growth path. How does your organisation currently use AI to address this?",
    type: "mcq",
    options: [
      { label: "A", text: "Managers handle this manually; there's no structured AI-enabled EX programme", score: 0 },
      { label: "B", text: "We use annual engagement surveys and share results in a static dashboard", score: 1 },
      { label: "C", text: "We use AI tools (e.g. Leapsome, Glint) for continuous pulse surveys, sentiment analysis, and AI-suggested career path nudges based on skill gaps", score: 2 },
      { label: "D", text: "We have an AI-powered internal mobility platform with personalised learning journeys (e.g. Eightfold.ai), burnout risk scoring via workload signals, and manager 1:1 prep assistants", score: 3 },
    ],
  },
  {
    id: 4,
    domain: "HR Policy & Compliance",
    icon: "📋",
    question: "Employees frequently ask HR about leave policies, benefits, and compliance queries. How does your team handle this at scale?",
    type: "mcq",
    options: [
      { label: "A", text: "Employees email or call HR directly; there is no self-service system", score: 0 },
      { label: "B", text: "We have a static FAQ page or intranet portal employees can refer to", score: 1 },
      { label: "C", text: "We have an AI chatbot (e.g. Leena AI, ServiceNow HR) that handles common policy Q&As, routes complex cases to HR, and logs query patterns for policy updates", score: 2 },
      { label: "D", text: "We have a generative AI-powered HR assistant integrated with HRIS + policy docs that gives personalised, contextual answers, flags compliance risks, and auto-updates when policies change", score: 3 },
    ],
  },
  {
    id: 5,
    domain: "Employer Branding",
    icon: "✨",
    question: "Your organisation wants to improve its employer brand and attract top talent on LinkedIn and Glassdoor. How do you use AI in this strategy?",
    type: "mcq",
    options: [
      { label: "A", text: "We rely on word-of-mouth and HR manually posts job ads without any content strategy", score: 0 },
      { label: "B", text: "We use LinkedIn Recruiter and occasionally run sponsored ads; content is created manually", score: 1 },
      { label: "C", text: "We use AI tools (e.g. Phenom People, Beamery) to personalise career site content, auto-generate targeted job ad copy, and analyse Glassdoor sentiment to inform EVP messaging", score: 2 },
      { label: "D", text: "We run an AI-driven employer brand engine: social listening tools surface brand sentiment, generative AI creates persona-specific content, and predictive analytics optimise channel spend and candidate conversion rates", score: 3 },
    ],
  },
  {
    id: 6,
    domain: "Learning & Development",
    icon: "🧠",
    question: "Your L&D team needs to upskill 500 employees across 5 departments with different skill gaps. What's your AI-enabled approach?",
    type: "mcq",
    options: [
      { label: "A", text: "We assign a standard training curriculum to everyone regardless of role or gaps", score: 0 },
      { label: "B", text: "We track learning completion in an LMS (e.g. Cornerstone) but don't personalise paths", score: 1 },
      { label: "C", text: "We use AI in our LMS to assess skill gaps and recommend role-specific learning paths; training effectiveness is tracked via assessments", score: 2 },
      { label: "D", text: "We use a skills intelligence platform (e.g. Degreed, EdCast) with ML that maps skills to business goals, auto-curates external content, and predicts ROI of each learning intervention per employee", score: 3 },
    ],
  },
  {
    id: 7,
    domain: "Workforce Planning",
    icon: "🗺️",
    question: "Your organisation is planning for a major expansion into 3 new markets next year. How does AI support your workforce planning?",
    type: "mcq",
    options: [
      { label: "A", text: "We do manual headcount planning in Excel based on past data and manager requests", score: 0 },
      { label: "B", text: "We use HRIS reports and some benchmarking data to estimate hiring needs", score: 1 },
      { label: "C", text: "We use workforce planning software (e.g. Anaplan, Workday Adaptive) with scenario modelling, skills gap analysis, and internal talent mobility mapping", score: 2 },
      { label: "D", text: "We use AI-driven strategic workforce planning with real-time labour market intelligence (e.g. Lightcast), Monte Carlo scenario simulations, and an integrated talent marketplace that auto-surfaces internal candidates for future roles", score: 3 },
    ],
  },
];

const levels = [
  {
    name: "Beginner",
    range: [0, 30],
    color: "#e74c3c",
    bg: "rgba(231, 76, 60, 0.12)",
    border: "#e74c3c",
    emoji: "🌱",
    summary: "Your HR function is largely running on manual processes with limited or no AI integration. You're at the starting point of an important transformation journey.",
    steps: [
      "Start with one high-impact, low-complexity AI use case — AI-powered resume screening is the fastest win for most HR teams.",
      "Enroll in AIHR's free 'Introduction to AI in HR' course to build foundational vocabulary and confidence.",
      "Audit your current HRIS (Workday, SAP SuccessFactors, BambooHR) — most already include AI features you may not be activating.",
      "Shadow or benchmark against one AI-forward HR team in your industry using case studies from Unilever, IBM, or Walmart.",
      "Set a 90-day goal: implement one AI chatbot for HR policy Q&A to reduce ticket volume.",
    ],
    courses: [
      { name: "AIHR – AI for HR Certificate (Free intro module)", url: "https://www.aihr.com/courses/artificial-intelligence-for-hr/" },
      { name: "Coursera – AI For Everyone by Andrew Ng (Free audit)", url: "https://www.coursera.org/learn/ai-for-everyone" },
      { name: "LinkedIn Learning – HR Analytics & AI Foundations", url: "https://www.linkedin.com/learning/" },
    ],
    caseStudy: "Unilever automated screening of 1.8M annual job applications using AI, saving 70,000 HR hours and cutting recruitment time by 100,000 hours annually.",
  },
  {
    name: "Emerging",
    range: [31, 55],
    color: "#f39c12",
    bg: "rgba(243, 156, 18, 0.12)",
    border: "#f39c12",
    emoji: "🔥",
    summary: "You've adopted basic AI tools and are beginning to see value in analytics. Now it's time to go deeper — move from reactive data use to proactive, predictive decision-making.",
    steps: [
      "Upgrade from static dashboards to a people analytics platform (Visier, One Model, or Power BI with ML plugins) to enable predictive attrition modelling.",
      "Pilot a continuous listening programme using AI sentiment analysis (e.g. Qualtrics XM, Glint) to replace or supplement annual engagement surveys.",
      "Train your HRBP team on data literacy — ability to interpret AI outputs is as important as using the tools.",
      "Evaluate your ATS for AI scoring capabilities; if limited, explore platforms like Greenhouse or Lever that offer native AI features.",
      "Develop an internal AI use policy for HR to ensure ethical, compliant usage of AI in hiring and performance decisions.",
    ],
    courses: [
      { name: "AIHR – People Analytics Certificate", url: "https://www.aihr.com/courses/people-analytics/" },
      { name: "ISB Online – Transforming HR with Analytics & AI (16-week)", url: "https://online-em.isb.edu/transforming-hr-with-analytics-and-ai" },
      { name: "Google – Data Analytics Certificate (Coursera, free audit)", url: "https://www.coursera.org/professional-certificates/google-data-analytics" },
    ],
    caseStudy: "Udemy deployed an AI-based performance & OKR platform as it scaled to 1,100+ employees, improving feedback participation from 70% to over 92% and achieving 85% goal completion rates.",
  },
  {
    name: "Proficient",
    range: [56, 80],
    color: "#27ae60",
    bg: "rgba(39, 174, 96, 0.12)",
    border: "#27ae60",
    emoji: "⚡",
    summary: "AI is meaningfully embedded across your HR workflows. You're making data-driven decisions with confidence. The next frontier is building proprietary models and scaling AI into strategy.",
    steps: [
      "Pilot a skills intelligence platform (Degreed, Eightfold.ai) to create a dynamic internal talent marketplace and reduce reliance on external hiring.",
      "Build a custom attrition prediction model using your HRIS data with Python/R or low-code ML tools (e.g. DataRobot, H2O.ai).",
      "Integrate your generative AI assistant with live HRIS data so employees get real-time, personalised answers on payroll, benefits, and policies.",
      "Partner with your employer branding team to use AI social listening to continuously track EVP sentiment and adjust messaging.",
      "Establish an HR AI governance committee with clear audit trails, bias review processes, and explainability standards for all AI-driven HR decisions.",
    ],
    courses: [
      { name: "MIT Sloan – AI: Implications for Business Strategy (Executive Ed)", url: "https://exec.mit.edu/" },
      { name: "AIHR – Strategic HR Leadership Certificate", url: "https://www.aihr.com/courses/hr-leadership/" },
      { name: "fast.ai – Practical Deep Learning (Free, for building custom models)", url: "https://www.fast.ai/" },
    ],
    caseStudy: "Walmart's GenAI-powered 'My Assistant' app handles document drafting, policy queries, and career management for campus employees, freeing HR teams to focus on strategic initiatives.",
  },
  {
    name: "Advanced",
    range: [81, 100],
    color: "#8e44ad",
    bg: "rgba(142, 68, 173, 0.12)",
    border: "#8e44ad",
    emoji: "🚀",
    summary: "You are at the frontier of AI-driven HR. Your function operates with custom ML models, generative AI in production, and positions HR as a true competitive advantage for the business.",
    steps: [
      "Contribute to the field — publish case studies, speak at SHRM/HRTech conferences, and mentor emerging HR teams to accelerate industry adoption.",
      "Explore agentic AI workflows where AI can autonomously handle end-to-end processes (e.g. full-cycle internal mobility without human trigger).",
      "Build a real-time HR AI dashboard for the C-suite that synthesises talent risk, skills gaps, and workforce ROI in a single view.",
      "Evaluate responsible AI frameworks — partner with legal/compliance to ensure GDPR, EEOC, and AI Act compliance as your models scale.",
      "Develop an internal AI HR certification programme to upskill all HR staff and create a community of practice.",
    ],
    courses: [
      { name: "Stanford HAI – AI in Business (Advanced Executive Programme)", url: "https://hai.stanford.edu/" },
      { name: "Anthropic – Prompt Engineering for Enterprise Use Cases", url: "https://www.anthropic.com/" },
      { name: "SHRM – AI in HR Certification Track", url: "https://www.shrm.org/" },
    ],
    caseStudy: "IBM's Watson Talent Insights predicts employee attrition with 95% accuracy, enabling proactive retention interventions that IBM credits with saving hundreds of millions in turnover costs annually.",
  },
];

function getLevel(score, total) {
  const pct = Math.round((score / total) * 100);
  return { pct, level: levels.find(l => pct >= l.range[0] && pct <= l.range[1]) || levels[3] };
}

const domainColors = {
  "Talent Acquisition": "#3498db",
  "HR Analytics": "#9b59b6",
  "Employee Experience": "#e67e22",
  "HR Policy & Compliance": "#1abc9c",
  "Employer Branding": "#e91e8c",
  "Learning & Development": "#f39c12",
  "Workforce Planning": "#2ecc71",
};

export default function App() {
  const [answers, setAnswers] = useState({});
  const [current, setCurrent] = useState(0);
  const [phase, setPhase] = useState("intro");
  const [animating, setAnimating] = useState(false);

  const maxScore = questions.length * 3;
  const score = Object.values(answers).reduce((a, b) => a + b, 0);

  function selectAnswer(qId, s) {
    setAnswers(prev => ({ ...prev, [qId]: s }));
  }

  function next() {
    if (current < questions.length - 1) {
      setAnimating(true);
      setTimeout(() => { setCurrent(c => c + 1); setAnimating(false); }, 220);
    } else {
      setPhase("result");
    }
  }

  function prev() {
    if (current > 0) {
      setAnimating(true);
      setTimeout(() => { setCurrent(c => c - 1); setAnimating(false); }, 220);
    }
  }

  function reset() {
    setAnswers({});
    setCurrent(0);
    setPhase("intro");
  }

  const q = questions[current];
  const answered = answers[q?.id] !== undefined;
  const progress = ((current + (answered ? 1 : 0)) / questions.length) * 100;
  const { pct, level } = getLevel(score, maxScore);

  const domainScores = questions.map(q => ({
    domain: q.domain,
    icon: q.icon,
    color: domainColors[q.domain],
    score: answers[q.id] ?? 0,
    max: 3,
  }));

  // ── INTRO ──────────────────────────────────────────────────────────────────
  if (phase === "intro") return (
    <div style={{ minHeight: "100vh", background: "#0a0a0f", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Georgia', 'Times New Roman', serif", padding: "24px" }}>
      <div style={{ maxWidth: 640, width: "100%", textAlign: "center" }}>
        <div style={{ fontSize: 56, marginBottom: 16 }}>🤖</div>
        <div style={{ fontSize: 11, letterSpacing: "0.25em", color: "#666", textTransform: "uppercase", marginBottom: 12, fontFamily: "monospace" }}>Proficiency Assessment</div>
        <h1 style={{ fontSize: "clamp(28px, 5vw, 44px)", fontWeight: 700, color: "#f0f0f0", lineHeight: 1.15, margin: "0 0 16px" }}>
          AI in HR<br /><span style={{ color: "#c084fc" }}>Capability Index</span>
        </h1>
        <p style={{ color: "#888", fontSize: 16, lineHeight: 1.7, marginBottom: 32, fontFamily: "system-ui, sans-serif" }}>
          7 real-world scenarios across Talent Acquisition, Analytics, Employee Experience, Policy, Employer Branding, L&D, and Workforce Planning. Discover your proficiency tier and get a personalised 90-day growth roadmap.
        </p>
        <div style={{ display: "flex", gap: 8, justifyContent: "center", flexWrap: "wrap", marginBottom: 40 }}>
          {[["🌱", "Beginner"], ["🔥", "Emerging"], ["⚡", "Proficient"], ["🚀", "Advanced"]].map(([e, n]) => (
            <div key={n} style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 8, padding: "8px 16px", fontSize: 13, color: "#aaa", fontFamily: "system-ui, sans-serif" }}>
              {e} {n}
            </div>
          ))}
        </div>
        <button onClick={() => setPhase("quiz")} style={{ background: "linear-gradient(135deg, #c084fc, #818cf8)", border: "none", borderRadius: 12, padding: "16px 48px", fontSize: 16, fontWeight: 600, color: "#fff", cursor: "pointer", fontFamily: "system-ui, sans-serif", letterSpacing: "0.03em" }}>
          Begin Assessment →
        </button>
        <p style={{ color: "#555", fontSize: 12, marginTop: 16, fontFamily: "monospace" }}>~5 minutes · 7 questions · Instant results</p>
      </div>
    </div>
  );

  // ── QUIZ ───────────────────────────────────────────────────────────────────
  if (phase === "quiz") return (
    <div style={{ minHeight: "100vh", background: "#0a0a0f", fontFamily: "system-ui, -apple-system, sans-serif", padding: "24px 16px" }}>
      <div style={{ maxWidth: 680, margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 28 }}>
          <div style={{ fontSize: 13, color: "#555", fontFamily: "monospace" }}>Question {current + 1} / {questions.length}</div>
          <div style={{ fontSize: 13, color: "#555", fontFamily: "monospace" }}>{Object.keys(answers).length} answered</div>
        </div>
        <div style={{ background: "rgba(255,255,255,0.05)", borderRadius: 4, height: 4, marginBottom: 36, overflow: "hidden" }}>
          <div style={{ height: "100%", background: "linear-gradient(90deg, #c084fc, #818cf8)", width: `${progress}%`, transition: "width 0.4s ease", borderRadius: 4 }} />
        </div>
        <div style={{ marginBottom: 16 }}>
          <span style={{ background: `${domainColors[q.domain]}22`, border: `1px solid ${domainColors[q.domain]}55`, color: domainColors[q.domain], borderRadius: 20, padding: "4px 14px", fontSize: 12, fontWeight: 600, letterSpacing: "0.05em" }}>
            {q.icon} {q.domain}
          </span>
        </div>
        <div style={{ opacity: animating ? 0 : 1, transform: animating ? "translateY(8px)" : "translateY(0)", transition: "all 0.22s ease" }}>
          <h2 style={{ fontSize: "clamp(17px, 3vw, 21px)", fontWeight: 600, color: "#e8e8e8", lineHeight: 1.5, marginBottom: 28, fontFamily: "Georgia, serif" }}>
            {q.question}
          </h2>
          <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 32 }}>
            {q.options.map(opt => {
              const selected = answers[q.id] === opt.score;
              return (
                <button key={opt.label} onClick={() => selectAnswer(q.id, opt.score)}
                  style={{ display: "flex", alignItems: "flex-start", gap: 14, textAlign: "left", background: selected ? "rgba(192, 132, 252, 0.12)" : "rgba(255,255,255,0.03)", border: selected ? "1.5px solid #c084fc" : "1px solid rgba(255,255,255,0.07)", borderRadius: 12, padding: "14px 18px", cursor: "pointer", transition: "all 0.18s ease", color: selected ? "#e8d8ff" : "#aaa" }}>
                  <span style={{ fontWeight: 700, fontSize: 13, color: selected ? "#c084fc" : "#555", flexShrink: 0, marginTop: 1, minWidth: 18, fontFamily: "monospace" }}>{opt.label}</span>
                  <span style={{ fontSize: 14, lineHeight: 1.6 }}>{opt.text}</span>
                </button>
              );
            })}
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <button onClick={prev} disabled={current === 0}
              style={{ background: "none", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, padding: "10px 24px", color: current === 0 ? "#333" : "#888", cursor: current === 0 ? "default" : "pointer", fontSize: 14 }}>
              ← Back
            </button>
            <button onClick={next} disabled={!answered}
              style={{ background: answered ? "linear-gradient(135deg, #c084fc, #818cf8)" : "rgba(255,255,255,0.05)", border: "none", borderRadius: 8, padding: "10px 28px", color: answered ? "#fff" : "#444", cursor: answered ? "pointer" : "default", fontSize: 14, fontWeight: 600, transition: "all 0.2s" }}>
              {current === questions.length - 1 ? "View Results →" : "Next →"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  // ── RESULTS ────────────────────────────────────────────────────────────────
  return (
    <div style={{ minHeight: "100vh", background: "#0a0a0f", fontFamily: "system-ui, -apple-system, sans-serif", padding: "32px 16px" }}>
      <div style={{ maxWidth: 720, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 40 }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>{level.emoji}</div>
          <div style={{ fontSize: 11, color: "#555", letterSpacing: "0.2em", textTransform: "uppercase", fontFamily: "monospace", marginBottom: 8 }}>Your Proficiency Level</div>
          <h2 style={{ fontSize: 38, fontWeight: 800, color: level.color, margin: "0 0 4px", fontFamily: "Georgia, serif" }}>{level.name}</h2>
          <div style={{ fontSize: 28, fontWeight: 700, color: "#f0f0f0", marginBottom: 16 }}>{pct}%</div>
          <div style={{ background: "rgba(255,255,255,0.05)", borderRadius: 8, height: 10, maxWidth: 380, margin: "0 auto 20px", overflow: "hidden" }}>
            <div style={{ height: "100%", background: `linear-gradient(90deg, ${level.color}88, ${level.color})`, width: `${pct}%`, borderRadius: 8, transition: "width 1s ease" }} />
          </div>
          <p style={{ color: "#999", fontSize: 15, lineHeight: 1.7, maxWidth: 560, margin: "0 auto" }}>{level.summary}</p>
        </div>

        {/* Domain Breakdown */}
        <div style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: 24, marginBottom: 24 }}>
          <h3 style={{ fontSize: 13, letterSpacing: "0.15em", textTransform: "uppercase", color: "#555", marginBottom: 20, fontFamily: "monospace" }}>Domain Breakdown</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {domainScores.map(d => {
              const dpct = Math.round((d.score / d.max) * 100);
              const dlabel = dpct <= 30 ? "Beginner" : dpct <= 55 ? "Emerging" : dpct <= 80 ? "Proficient" : "Advanced";
              return (
                <div key={d.domain} style={{ display: "flex", alignItems: "center", gap: 12 }}>
                  <div style={{ width: 28, textAlign: "center", fontSize: 16 }}>{d.icon}</div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                      <span style={{ fontSize: 13, color: "#ccc", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{d.domain}</span>
                      <span style={{ fontSize: 12, color: d.color, marginLeft: 8, flexShrink: 0 }}>{dlabel}</span>
                    </div>
                    <div style={{ background: "rgba(255,255,255,0.05)", borderRadius: 4, height: 5, overflow: "hidden" }}>
                      <div style={{ height: "100%", background: d.color, width: `${dpct}%`, borderRadius: 4, transition: "width 0.8s ease" }} />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Roadmap */}
        <div style={{ background: level.bg, border: `1px solid ${level.border}33`, borderRadius: 16, padding: 24, marginBottom: 24 }}>
          <h3 style={{ fontSize: 13, letterSpacing: "0.15em", textTransform: "uppercase", color: level.color, marginBottom: 20, fontFamily: "monospace" }}>
            📍 Your 90-Day Growth Roadmap
          </h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {level.steps.map((step, i) => (
              <div key={i} style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
                <div style={{ width: 24, height: 24, borderRadius: "50%", background: `${level.color}33`, border: `1px solid ${level.color}55`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, color: level.color, flexShrink: 0, fontFamily: "monospace" }}>
                  {i + 1}
                </div>
                <p style={{ color: "#ccc", fontSize: 14, lineHeight: 1.65, margin: 0 }}>{step}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Courses */}
        <div style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: 24, marginBottom: 24 }}>
          <h3 style={{ fontSize: 13, letterSpacing: "0.15em", textTransform: "uppercase", color: "#555", marginBottom: 16, fontFamily: "monospace" }}>📚 Recommended Courses & Resources</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {level.courses.map((c, i) => (
              <a key={i} href={c.url} target="_blank" rel="noopener noreferrer"
                style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 14px", background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 8, textDecoration: "none", color: "#c8b4ff", fontSize: 14 }}>
                <span style={{ fontSize: 16 }}>🔗</span>
                {c.name}
              </a>
            ))}
          </div>
        </div>

        {/* Case Study */}
        <div style={{ background: "rgba(192, 132, 252, 0.06)", border: "1px solid rgba(192, 132, 252, 0.2)", borderRadius: 16, padding: 22, marginBottom: 32 }}>
          <div style={{ fontSize: 11, letterSpacing: "0.15em", color: "#c084fc", textTransform: "uppercase", fontFamily: "monospace", marginBottom: 10 }}>💡 Real-World Case Study at Your Level</div>
          <p style={{ color: "#ddd", fontSize: 14, lineHeight: 1.7, margin: 0 }}>{level.caseStudy}</p>
        </div>

        {/* Tier Legend */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 10, marginBottom: 32 }}>
          {levels.map(l => {
            const active = l.name === level.name;
            return (
              <div key={l.name} style={{ background: active ? l.bg : "rgba(255,255,255,0.02)", border: `1px solid ${active ? l.border : "rgba(255,255,255,0.05)"}`, borderRadius: 10, padding: "10px 14px" }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: active ? l.color : "#555" }}>{l.emoji} {l.name}</div>
                <div style={{ fontSize: 11, color: "#555", marginTop: 2, fontFamily: "monospace" }}>{l.range[0]}–{l.range[1]}%</div>
              </div>
            );
          })}
        </div>

        <div style={{ textAlign: "center" }}>
          <button onClick={reset} style={{ background: "none", border: "1px solid rgba(255,255,255,0.15)", borderRadius: 10, padding: "12px 32px", color: "#888", cursor: "pointer", fontSize: 14 }}>
            ↩ Retake Assessment
          </button>
        </div>
      </div>
    </div>
  );
}
